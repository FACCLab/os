/**
 * @file texttwist_dict.h
 * @brief Declarations for the TextTwist dictionary
 *
 * @author mischnal
 */
#ifndef _TEXTTWIST_DICT_H_
#define _TEXTTWIST_DICT_H_

extern char texttwist_dict[];

#endif /* _TEXTTWIST_DICT_H_ */
